from django.contrib import admin
from .models import *


admin.site.register(Event)
admin.site.register(EventRegister)
# Register your models here.
